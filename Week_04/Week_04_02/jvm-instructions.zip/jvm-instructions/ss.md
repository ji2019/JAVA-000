```
一 未归类系列A
此系列暂未归类
指令码    助记符                            说明
0x00         nop                                什么都不做
0x01        aconst_null                   将null推至栈顶
```

```
二 const系列
该系列命令主要负责把简单的数值类型送到栈顶，该系列命令不带参数。注意只把简单的数值类型送到栈顶时，才使用如下的命令
比如对应int型才该方式只能把-1,0,1,2,3,4,5（分别采用iconst_m1,iconst_0, iconst_1, iconst_2, iconst_3,
iconst_4, iconst_5）
送到栈顶对于int型，其他的数值请使用push系列命令（比如bipush）
指令码        助记符                            说明
0x02 		iconst_m1                   将int型(-1)推至栈顶
0x03         iconst_0                    将int型(0)推至栈顶
0x04         iconst_1                    将int型(1)推至栈顶
0x05         iconst_2                    将int型(2)推至栈顶
0x06         iconst_3                    将int型(3)推至栈顶
0x07         iconst_4                    将int型(4)推至栈顶
0x08         iconst_5                    将int型(5)推至栈顶
0x09 		lconst_0                    将long型(0)推至栈顶
0x0a         lconst_1                    将long型(1)推至栈顶
0x0b		fconst_0                    将float型(0)推至栈顶
0x0c         fconst_1                    将float型(1)推至栈顶
0x0d         fconst_2                    将float型(2)推至栈顶
0x0e		dconst_0                    将double型(0)推至栈顶
0x0f         dconst_1                    将double型(1)推至栈顶
```

```
三 push 系列
该系列命令负责把一个整形数字（长度比较小）送到到栈顶。该系列命令有一个参数，用于指定要送到栈顶的数字。
注意该系列命令只能操作一定范围内的整形数值，超出该围的使用将使用ldc命令系列
指令码    助记符                          说明
0x10       bipush     将单字的常量值(-128~127)推至栈顶
0x11       sipush     将一个短整型常量值(-32768~32767)推至栈顶
```

```
四 ldc 系列
该系列命令负责把数值常量或String常量值从常量池中推至栈顶。该命令后面需要给一个表示常量在常量中位置(编号)参数，
哪些常量是放在常量池呢?如：final static int id=32768; final static float double=6.5
对于const系列命令和push系列命令操作范围之外的数值类型常量，都放在常量池中.
另外，所有不是通过new创建的String都是放在常量池中的
指令码    助记词                    说明
0x12          ldc                 将int, float或String型常量值从常量池中推至栈顶
0x13          ldc_w               将int, float或String型常量值从常量池中推至栈顶（宽索引）
0x14          ldc2_w             将long或double型常量值从常量池中推至栈顶（宽索引）
```





十九 new及数组系列
该系列用于创建一个对对象或数组 比如代码

```
package learn;

public class Bytecode19 {
	void test() {
		int ids[] = new int[5];
		Object objs[] = new Object[5];
		Object obj = new Object();
		Hello hello = new Hello();
		int len = objs.length;
	}
}
```

```
$ javap -c Bytecode19.class
Compiled from "Bytecode19.java"
public class learn.Bytecode19 {
  public learn.Bytecode19();
    Code:
       0: aload_0
       1: invokespecial #8                  // Method java/lang/Object."<init>":()V
       4: return

  void test();
    Code:
       0: iconst_5
       1: newarray       int
       3: astore_1
       4: iconst_5
       5: anewarray     #3                  // class java/lang/Object
       8: astore_2
       9: new           #3                  // class java/lang/Object
      12: dup
      13: invokespecial #8                  // Method java/lang/Object."<init>":()V
      16: astore_3
      17: new           #15                 // class learn/Hello
      20: dup
      21: invokespecial #17                 // Method learn/Hello."<init>":()V
      24: astore        4
      26: aload_2
      27: arraylength
      28: istore        5
      30: return
}

```

```
指令码      助记符                          说明
0xbb        new                   创建一个对象，并将其引用值压入栈顶
0xbc        newarray              创建一个指定原始类型（如int, float,char…）的数组，并将其引用值压入栈顶
0xbd        anewarray             创建一个引用型（如类，接口，数组）的数组，并将其引用值压入栈顶
0xbe        arraylength           获得数数组的长度值并压入栈顶
```

