**字节码阅读例子**

```
javap ‐c demo.jvm0104.HelloByteCode
# 或者:
javap ‐c demo/jvm0104/HelloByteCode
javap ‐c demo/jvm0104/HelloByteCode.class
OK，我们成功获取到了字节码清单, 下面进行简单的解读。
```

```

```

