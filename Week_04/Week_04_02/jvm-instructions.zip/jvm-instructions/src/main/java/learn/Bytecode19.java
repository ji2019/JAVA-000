package learn;

public class Bytecode19 {
	void test() {
		int ids[] = new int[5];
		Object objs[] = new Object[5];
		Object obj = new Object();
		Hello hello = new Hello();
		int len = objs.length;
	}
}
